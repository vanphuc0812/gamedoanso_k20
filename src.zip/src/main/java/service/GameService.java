package service;

import model.Game;
import model.Guess;
import repository.GameRepository;

public class GameService {
    GameRepository repository = new GameRepository();

    public Game createGame(String username) {
        repository.deactiveAllGame(username);
        Game newGame = new Game(username);
        repository.save(newGame);
        return newGame;
    }

    public Game loadGame(String username) {
        Game game = repository.loadActiveGameByUsername(username);
        if (game == null) return createGame(username);
        return game;
    }

    public Game processGame(String gameID, int guessNumber) {
        int guessResult;
        Game game = repository.loadGameByGameID(gameID);
        if (guessNumber > game.getTargetNumber()) {
            guessResult = 1;
        } else if (guessNumber < game.getTargetNumber()) {
            guessResult = -1;
        } else {
            guessResult = 0;
        }
        Guess guess = new Guess(guessNumber, gameID, guessResult);
        return null;
    }
}
